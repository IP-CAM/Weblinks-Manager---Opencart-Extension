<?php
class ModelModuleWebLinksManager extends Model {
/*
* Create our database table to store the links
*/
	public function createModuleTables() {
		$query = $this->db->query("CREATE TABLE IF NOT EXISTS " . DB_PREFIX . "weblinks (links_id INT(11) AUTO_INCREMENT, links_name VARCHAR(255), links_email VARCHAR(255), links_title text, links_url text, links_desc text, links_status INT(1), PRIMARY KEY (links_id))");
	}	
	
/*
* Add a new link to the database table
*/
	public function addLink($data) {
      	$this->db->query("INSERT INTO " . DB_PREFIX . "weblinks SET links_name = '" . $this->db->escape($data['name']) . "', links_email = '" . $this->db->escape($data['email']) . "', links_title = '" . $this->db->escape($data['title']) . "', links_url = '" . $this->db->escape($data['url']) . "', links_desc = '" . $this->db->escape($data['description']) . "', links_status = '" . $this->db->escape($data['status']) . "'");
	}
	
/*
* Edit and update an existing link in the database table
*/
	public function editLink($links_id, $data) {
      	$this->db->query("UPDATE " . DB_PREFIX . "weblinks SET links_name = '" . $this->db->escape($data['name']) . "', links_email = '" . $this->db->escape($data['email']) . "', links_title = '" . $this->db->escape($data['title']) . "', links_url = '" . $this->db->escape($data['url']) . "', links_desc = '" . $this->db->escape($data['description']) . "', links_status = '" . $this->db->escape($data['status']) . "' WHERE links_id = '" . (int)$links_id . "'");
	}
	
/*
* Delete an existing link in the database table
*/
	public function deleteLink($link_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "weblinks WHERE links_id = '" . (int)$link_id . "'");
		
		$this->cache->delete('product');
	}

/*
* Get an existing link from the database table
*/
	public function getLink($links_id) {
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "weblinks WHERE links_id = '" . (int)$links_id . "'");
		return $query->row;
	}
	
/*
* Get all existing links from the database table
*/
	public function getAllLinks() {
		$sql = "SELECT * FROM " . DB_PREFIX . "weblinks ORDER BY links_id DESC";
		$query = $this->db->query($sql);
		$weblinks = $query->rows;
		return $weblinks;
	}

/*
* Get a total of all existing links from the database table
*/
	public function getTotalLinks() {
		$sql = "SELECT COUNT(links_id) AS total FROM " . DB_PREFIX . "weblinks";
		$query = $this->db->query($sql);
		return $query->row['total'];
	}
}
?>