<?php
class ControllerModuleWebLinksManager extends Controller {
	
	private $error = array(); 
	
  	public function index() {
		$this->load->language('module/weblinksmanager');
    	
		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('module/weblinksmanager');
		
		$this->getList();
  	}

	
 /*
 * This function is called to load all web links from the database table.
 */
  	private function getList() {				
		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}
		
		$url = '';
		
		$this->load->model('module/weblinksmanager');
		
  		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
		$this->data['action'] = $this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'], 'SSL');
		
		$this->data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		$this->data['insert'] = $this->url->link('module/weblinksmanager/insert', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$this->data['delete'] = $this->url->link('module/weblinksmanager/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');	
	

		$this->data['weblinks'] = array();
		
		$links_total = $this->model_module_weblinksmanager->getTotalLinks();
		$results = $this->model_module_weblinksmanager->getAllLinks();
				    	
		foreach ($results as $result) {
 			$action = array();

			$action[] = array(
				'text' => $this->language->get('text_edit'),
				'href' => $this->url->link('module/weblinksmanager/update', 'token=' . $this->session->data['token'] . '&links_id=' . $result['links_id'] . $url, 'SSL')				
			);
						
		
      		$this->data['weblinks'][] = array(
				'linkid'     => $result['links_id'], 	
				'name'       => $result['links_name'], 	
				'email'      => $result['links_email'], 	
				'title'      => $result['links_title'], 	
				'url'        => $result['links_url'], 	
				'description'=> $result['links_desc'], 	
				'status'     => $result['links_status'],
				'selected'   => isset($this->request->post['selected']) && in_array($result['links_id'], $this->request->post['selected']),
				'action'     => $action
			);
    	}
		
		$this->data['heading_title'] = $this->language->get('heading_title');		
				
		$this->data['text_enabled'] = $this->language->get('text_enabled');		
		$this->data['text_disabled'] = $this->language->get('text_disabled');		
		$this->data['text_no_results'] = $this->language->get('text_no_results');		
    	$this->data['text_enabled'] = $this->language->get('text_enabled');
    	$this->data['text_disabled'] = $this->language->get('text_disabled');

		$this->data['column_name'] = $this->language->get('column_name');
		$this->data['column_email'] = $this->language->get('column_email');
		$this->data['column_title'] = $this->language->get('column_title');
		$this->data['column_url'] = $this->language->get('column_url');
		$this->data['column_description'] = $this->language->get('column_description');
		$this->data['column_status'] = $this->language->get('column_status');
		$this->data['column_action'] = $this->language->get('column_action');
				
		$this->data['button_insert'] = $this->language->get('button_insert');		
		$this->data['button_delete'] = $this->language->get('button_delete');		

 		$this->data['token'] = $this->session->data['token'];
		
 		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}

 		if (isset($this->session->data['success'])) {
			$this->data['success'] = $this->session->data['success'];
		
			unset($this->session->data['success']);
		} else {
			$this->data['success'] = '';
		}

 		$url = '';

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
 	   
		$pagination = new Pagination();
		$pagination->total = $links_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_admin_limit');
		$pagination->text = $this->language->get('text_pagination');
		$pagination->url = $this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');
		$this->data['pagination'] = $pagination->render();
	
			
		$this->template = 'module/weblinksmanager.tpl';
		$this->children = array(
			'common/header',
			'common/footer',
		);

		//Send the output.
		$this->response->setOutput($this->render());
  	}
	
 
 /*
 * This function is called to add a new link.
 */
  	public function insert() {
		$this->load->language('module/weblinksmanager');

    	$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('module/weblinksmanager');
			
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_module_weblinksmanager->addLink($this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			
			$url = '';
			
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			$this->redirect($this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}
    
    	$this->getForm();
  	} 
	

 /*
 * This function is called to update an edited link.
 */
  	public function update() {
		$this->load->language('module/weblinksmanager');

    	$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('module/weblinksmanager');
		
    	if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_module_weblinksmanager->editLink($this->request->get['links_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
			
			$this->redirect($this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}
    
    	$this->getForm();
  	}   
	


 /*
 * This function is called to delete a link/ links from the table.
 */
  	public function delete() {
		$this->load->language('module/weblinksmanager');

    	$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('module/weblinksmanager');
		
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $link_id) {			
				$this->model_module_weblinksmanager->deleteLink($link_id);
			}
			
			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';
			
			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}
						
			$this->redirect($this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getList();
	}
			
			
			 
 /*
 * This function is called to generate the form.
 */
  	private function getForm() {
		$this->load->language('module/weblinksmanager');

    	$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('module/weblinksmanager');
		
		$this->data['heading_title'] = $this->language->get('heading_title');		

		$this->data['entry_name'] = $this->language->get('entry_name');
		$this->data['entry_email'] = $this->language->get('entry_email');
		$this->data['entry_title'] = $this->language->get('entry_title');
		$this->data['entry_url'] = $this->language->get('entry_url');
    	$this->data['entry_desc'] = $this->language->get('entry_desc');
    	$this->data['entry_status'] = $this->language->get('entry_status');

		$this->data['tab_general'] = $this->language->get('tab_general');
    	$this->data['text_enabled'] = $this->language->get('text_enabled');
    	$this->data['text_disabled'] = $this->language->get('text_disabled');

		$this->data['button_save'] = $this->language->get('button_save');
    	$this->data['button_cancel'] = $this->language->get('button_cancel');
		

 		if (isset($this->error['warning'])) {
			$this->data['error_warning'] = $this->error['warning'];
		} else {
			$this->data['error_warning'] = '';
		}
		
 		if (isset($this->error['name'])) {
			$this->data['error_name'] = $this->error['name'];
		} else {
			$this->data['error_name'] = '';
		}
		    
 		if (isset($this->error['email'])) {
			$this->data['error_email'] = $this->error['email'];
		} else {
			$this->data['error_email'] = '';
		}

 		if (isset($this->error['title'])) {
			$this->data['error_title'] = $this->error['title'];
		} else {
			$this->data['error_title'] = '';
		}
			
 		if (isset($this->error['url'])) {
			$this->data['error_url'] = $this->error['url'];
		} else {
			$this->data['error_url'] = '';
		}
			
			
		$url = '';
		
		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
	
  		$this->data['breadcrumbs'] = array();

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => false
   		);

   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);
		
   		$this->data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title'),
			'href'      => $this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'], 'SSL'),
      		'separator' => ' :: '
   		);

		if (!isset($this->request->get['links_id'])) {
			$this->data['action'] = $this->url->link('module/weblinksmanager/insert', 'token=' . $this->session->data['token'] . $url, 'SSL');
		} else {
			$this->data['action'] = $this->url->link('module/weblinksmanager/update', 'token=' . $this->session->data['token'] . '&links_id=' . $this->request->get['links_id'] . $url, 'SSL');
		}
		
		$this->data['cancel'] = $this->url->link('module/weblinksmanager', 'token=' . $this->session->data['token'] . $url, 'SSL');

		$this->data['token'] = $this->session->data['token'];

    	if (isset($this->request->get['links_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
      		$links_info = $this->model_module_weblinksmanager->getLink($this->request->get['links_id']);
    	}

    	if (isset($this->request->post['name'])) {
      		$this->data['name'] = $this->request->post['name'];
    	} elseif (!empty($links_info)) {
			$this->data['name'] = $links_info['links_name'];
		} else {	
      		$this->data['name'] = '';
    	}

    	if (isset($this->request->post['email'])) {
      		$this->data['email'] = $this->request->post['email'];
    	} elseif (!empty($links_info)) {
			$this->data['email'] = $links_info['links_email'];
		} else {	
      		$this->data['email'] = '';
    	}

    	if (isset($this->request->post['title'])) {
      		$this->data['title'] = $this->request->post['title'];
    	} elseif (!empty($links_info)) {
			$this->data['title'] = $links_info['links_title'];
		} else {	
      		$this->data['title'] = '';
    	}

    	if (isset($this->request->post['url'])) {
      		$this->data['url'] = $this->request->post['url'];
    	} elseif (!empty($links_info)) {
			$this->data['url'] = $links_info['links_url'];
		} else {	
      		$this->data['url'] = '';
    	}

    	if (isset($this->request->post['description'])) {
      		$this->data['desc'] = $this->request->post['description'];
    	} elseif (!empty($links_info)) {
			$this->data['desc'] = $links_info['links_desc'];
		} else {	
      		$this->data['desc'] = '';
    	}

    	if (isset($this->request->post['status'])) {
      		$this->data['linkstatus'] = $this->request->post['status'];
    	} elseif (!empty($links_info)) {
			$this->data['linkstatus'] = $links_info['links_status'];
		} else {	
      		$this->data['linkstatus'] = '';
    	}


		$this->load->model('design/layout');
		
		$this->data['layouts'] = $this->model_design_layout->getLayouts();
		
		
		$this->template = 'module/weblinksmanager_form.tpl';
		$this->children = array(
			'common/header',
			'common/footer',
		);

		//Send the output.
		$this->response->setOutput($this->render());
  	}


 /*
 * This function is called to create the database tables we need during module installation.
 */
	public function install() {
		$this->load->model('module/weblinksmanager');
		$this->model_module_weblinksmanager->createModuleTables();
	}

	
/*
 * This function is called to ensure that the settings chosen by the admin user are allowed/valid.
 */
	private function validateDelete() {
		if (!$this->user->hasPermission('modify', 'module/weblinksmanager')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}	
	}
	
/*
 * This function is called to ensure that the settings chosen by the admin user are allowed/valid.
 */
	private function validate() {
		if (!$this->user->hasPermission('modify', 'module/weblinksmanager')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
    	if (utf8_strlen($this->request->post['name']) < 3) {
      		$this->error['name'] = $this->language->get('error_name');
    	}
		
		if (!preg_match('/^[^\@]+@.*\.[a-z]{2,6}$/i', $this->request->post['email'])) {
			$this->error['email'] = $this->language->get('error_email');
		}
		
		if (!preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $this->request->post['url'])) {
			$this->error['url'] = $this->language->get('error_url');
		}
		
    	if (utf8_strlen($this->request->post['title']) < 3) {
      		$this->error['title'] = $this->language->get('error_title');
    	}

		if (!$this->error) {
			return TRUE;
		} else {
			return FALSE;
		}	
	}
}
?>