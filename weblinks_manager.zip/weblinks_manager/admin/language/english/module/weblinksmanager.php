<?php
//Heading
$_['heading_title']    = 'WebLinks Manager';

// Text
$_['text_success']            = 'Success: You have modified Web Links Manager!';
$_['text_edit']               = 'Edit';
$_['text_enabled']            = 'Active';
$_['text_disabled']           = 'Disabled';
$_['text_pagination']         = 'Showing {start} to {end} of {total} ({pages} Pages)';
$_['text_no_results']         = 'No results!';
$_['text_separator']          = ' &gt; ';

// Column
$_['column_name']            = 'Name';
$_['column_email']           = 'Email';
$_['column_title']           = 'Link Title';
$_['column_url']             = 'Link URL';
$_['column_description']     = 'Link Description';
$_['column_status']          = 'Status';
$_['column_action']          = 'Action';

// Button
$_['button_insert']           = 'Insert';
$_['button_delete']           = 'Delete';
$_['button_save']             = 'Save';
$_['button_cancel']           = 'Cancel';

// Entry
$_['entry_name']              = 'Link Owner Name:';
$_['entry_email']             = 'Link Owner Email:';
$_['entry_title']             = 'Link Title:<br /><span class="help">Keep it short.</span>';
$_['entry_url']               = 'Link URL:<br /><span class="help">Enter the correct full URL starting with http://.</span>';
$_['entry_desc']              = 'Link Description:<br /><span class="help">Make it descriptive and not too long.</span>';
$_['entry_status']            = 'Link Status:';

// tabs
$_['tab_general']             = 'Web Link';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Web Links Manager!';
$_['error_name']         = 'Link Owner Name is required!';
$_['error_email']        = 'Invalid Email Address!';
$_['error_url']          = 'Invalid URL!';
$_['error_title']        = 'Link Title is required!';
?>