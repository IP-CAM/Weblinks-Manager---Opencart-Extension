<?php
class ModelModuleWebLinksManager extends Model {
	//Get all links from the database
	function getAllLinks() {
		$query = "SELECT * FROM " . DB_PREFIX . "weblinks WHERE links_status=1 ORDER BY links_id DESC";
		$result = $this->db->query($query);
		return $result->rows;
	}
}
?>