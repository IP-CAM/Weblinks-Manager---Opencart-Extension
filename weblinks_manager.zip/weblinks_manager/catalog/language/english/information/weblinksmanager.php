<?php
// Heading
$_['heading_title']     = 'Web Links / Resources';

?>